The following images and icons are made possible by FlatIcon and are not owned by myself.
You may find the media used for this project @ https://www.flaticon.com/free-icon/download_2996394

Copyright belongs to their respectful owners.
